package cn.dlc.yinrongshouhuoji.home.bean.intfc;

/**
 * Created by liuwenzhuo on 2018/3/13.
 */

public interface DeviceListBeanIntfc {
    String getDeviceNo();//设备编号

    String getDeviceName();//设备名称

    String getDeviceAddress();//设备地址
}
