package cn.dlc.yinrongshouhuoji.home.bean.intfc;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public interface ChooseGoodsListBeanIntfc {
    String getGoodsImg();//商品图片

    String getGoodsName();//商品名称

    float getGoodsPrice();//商品价格

    int getGoodsCount();//商品数量
}
