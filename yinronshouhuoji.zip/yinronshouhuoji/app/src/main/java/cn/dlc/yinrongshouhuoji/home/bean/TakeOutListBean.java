package cn.dlc.yinrongshouhuoji.home.bean;

import cn.dlc.yinrongshouhuoji.home.bean.intfc.TakeOutListBeanIntfc;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public class TakeOutListBean implements TakeOutListBeanIntfc {

    String gridNo;//格子编号

    String goodsName;//商品名称

    int goodsCount;//商品数量

    long date;//上架时间

    @Override
    public String getGridNo() {
        return gridNo;
    }

    @Override
    public String getGoodsName() {
        return goodsName;
    }

    @Override
    public int getGoodsCount() {
        return goodsCount;
    }

    @Override
    public long getDate() {
        return date;
    }

    public TakeOutListBean(String gridNo, String goodsName, int goodsCount, long date) {
        this.gridNo = gridNo;
        this.goodsName = goodsName;
        this.goodsCount = goodsCount;
        this.date = date;
    }

    @Override
    public String toString() {
        return "TakeOutListBean{"
            + "gridNo='"
            + gridNo
            + '\''
            + ", goodsName='"
            + goodsName
            + '\''
            + ", goodsCount="
            + goodsCount
            + ", date="
            + date
            + '}';
    }
}
