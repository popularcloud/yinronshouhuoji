package cn.dlc.yinrongshouhuoji.home.bean;

import cn.dlc.yinrongshouhuoji.home.bean.intfc.MessageListBeanIntfc;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public class MessageListBean implements MessageListBeanIntfc {

    String title;//标题

    String content;//内容

    long date;//时间

    int status;//消息状态 0未接单 1已接单 2通知类（具体看后台）

    //未接单情况下
    String phone;//用户电话

    String goodsName;//商品名称

    long bookDate;//预约配送时间

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getContent() {
        return content;
    }

    @Override
    public long getDate() {
        return date;
    }

    @Override
    public int getStatus() {
        return status;
    }

    @Override
    public String getPhone() {
        return phone;
    }

    @Override
    public String getGoodsName() {
        return goodsName;
    }

    @Override
    public long getBookDate() {
        return bookDate;
    }

    public MessageListBean(String title, String content, long date, int status, String phone,
        String goodsName, long bookDate) {
        this.title = title;
        this.content = content;
        this.date = date;
        this.status = status;
        this.phone = phone;
        this.goodsName = goodsName;
        this.bookDate = bookDate;
    }

    @Override
    public String toString() {
        return "MessageListBean{"
            + "title='"
            + title
            + '\''
            + ", content='"
            + content
            + '\''
            + ", date="
            + date
            + ", status="
            + status
            + ", phone='"
            + phone
            + '\''
            + ", goodsName='"
            + goodsName
            + '\''
            + ", bookDate="
            + bookDate
            + '}';
    }
}
