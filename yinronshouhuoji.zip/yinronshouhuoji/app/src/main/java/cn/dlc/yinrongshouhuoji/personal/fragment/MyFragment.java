package cn.dlc.yinrongshouhuoji.personal.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import cn.dlc.commonlibrary.ui.adapter.BaseRecyclerAdapter;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.fragment.BaseFragment;
import cn.dlc.yinrongshouhuoji.personal.activity.MenuDetailsActivity;
import cn.dlc.yinrongshouhuoji.personal.adapter.AllGreensAdapter;
import cn.dlc.yinrongshouhuoji.personal.adapter.AllItemAdapter;
import cn.dlc.yinrongshouhuoji.personal.bean.AllBean;
import cn.dlc.yinrongshouhuoji.personal.bean.MenuBean;
import java.util.ArrayList;

/**
 * 页面:李旭康  on  2018/3/14.
 * 对接口:
 * 作用:
 */

public class MyFragment extends BaseFragment {

    Unbinder unbinder;
    @BindView(R.id.recyclerview)
    RecyclerView mRecyclerview;
    @BindView(R.id.fragemt_all_tv)
    TextView mFragemtAllTv;
    @BindView(R.id.fragemt_cv)
    CardView mFragemtCv;
    @BindView(R.id.fragmemt_recyclerview)
    RecyclerView mFragmemtRecyclerview;

    private int mType;
    private ArrayList<AllBean> mLists;
    private ArrayList<MenuBean> mDatas;
    private ArrayList<MenuBean> mMenuBeans;
    private AllItemAdapter mItemAdapter;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_my;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
        @Nullable Bundle savedInstanceState) {
        Bundle bundle = getArguments();
        mType = bundle.getInt("TYPE");
        unbinder =
            ButterKnife.bind(this, super.onCreateView(inflater, container, savedInstanceState));
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        initData();
        initRecyclerview();
    }

    private void initRecyclerview() {
        switch (mType) {
            case 0:
                initAllAdapter();
                break;
            case 1:
                initOtherAdapter(mMenuBeans, "未派送",0);
                break;
            case 2:
                initOtherAdapter(mDatas, "已派送",1);
                break;
        }
    }

    /**
     * 全部的设置Adapter和数据
     */
    private void initAllAdapter() {
        mFragmemtRecyclerview.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mFragmemtRecyclerview.setVisibility(View.VISIBLE);
        mFragemtCv.setVisibility(View.GONE);
        AllGreensAdapter adapter = new AllGreensAdapter(getActivity());
        mFragmemtRecyclerview.setAdapter(adapter);
        adapter.setNewData(mLists);
        adapter.setClickListener(new AllGreensAdapter.ClickListener() {
           @Override
           public void onClick(int position) {
               Intent intent = new Intent(getActivity(), MenuDetailsActivity.class);
               intent.putExtra("TYPE",position);
               startActivity(intent);
           }
       });
        
       
    }

    /**
     * 未派送和已派送的设置data和adapter
     * @param list
     * @param s
     */

    private void initOtherAdapter(ArrayList<MenuBean> list, String s, final int type) {  
        mRecyclerview.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mItemAdapter = new AllItemAdapter();
        mFragmemtRecyclerview.setVisibility(View.GONE);
        mFragemtCv.setVisibility(View.VISIBLE);
        mRecyclerview.setAdapter(mItemAdapter);
        mItemAdapter.setNewData(list);
        mFragemtAllTv.setText(Html.fromHtml(getString(R.string.gongduos, list.size())));
        mItemAdapter.setOnItemClickListener(new BaseRecyclerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(ViewGroup parent, BaseRecyclerAdapter.CommonHolder holder,
                int position) {
                Intent intent = new Intent(getActivity(), MenuDetailsActivity.class);
                intent.putExtra("TYPE",type);
                startActivity(intent); 
            }
        });
    }

    private void initData() {
        //未派送的
        mMenuBeans = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            MenuBean bean = new MenuBean();
            bean.setGreensName("苦瓜炒蛋");
            bean.setPrice("18.00元");
            bean.setGresensNumb("X 1");
            mMenuBeans.add(bean);
        }
        //已经派送的
        mDatas = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            MenuBean bean = new MenuBean();
            bean.setGreensName("红烧鱼");
            bean.setPrice("18.00元");
            bean.setGresensNumb("X 1");
            mDatas.add(bean);
        }

        //全部
        mLists = new ArrayList<>();
        AllBean bean = new AllBean();
        bean.setGreesType("未派送");
        bean.setList(mMenuBeans);
        mLists.add(bean);

        AllBean bean3 = new AllBean();
        bean3.setGreesType("已派送");
        bean3.setList(mDatas);
        mLists.add(bean3);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
