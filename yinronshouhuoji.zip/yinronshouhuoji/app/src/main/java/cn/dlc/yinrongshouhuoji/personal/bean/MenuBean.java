package cn.dlc.yinrongshouhuoji.personal.bean;

/**
 * 页面:李旭康  on  2018/3/14.
 * 对接口:
 * 作用:
 */

public class MenuBean {

    //图片
    public int greensImg;
    public String greensName;
    public String price;
    public String gresensNumb;

    public int getGreensImg() {
        return greensImg;
    }

    public void setGreensImg(int greensImg) {
        this.greensImg = greensImg;
    }

    public String getGreensName() {
        return greensName;
    }

    public void setGreensName(String greensName) {
        this.greensName = greensName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getGresensNumb() {
        return gresensNumb;
    }

    public void setGresensNumb(String gresensNumb) {
        this.gresensNumb = gresensNumb;
    }

    @Override
    public String toString() {
        return "MenuBean{"
            + "greensImg="
            + greensImg
            + ", greensName='"
            + greensName
            + '\''
            + ", price='"
            + price
            + '\''
            + ", gresensNumb='"
            + gresensNumb
            + '\''
            + '}';
    }
}
