package cn.dlc.yinrongshouhuoji.personal.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.OnClick;
import cn.dlc.commonlibrary.ui.widget.TitleBar;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;
import cn.dlc.yinrongshouhuoji.personal.view.BottomDialog;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.request.RequestOptions;

/**
 * 页面:李旭康  on  2018/3/13.
 * 对接口:
 * 作用:
 */

public class PersonalDataActivity extends BaseActivity {
    @BindView(R.id.titleBar)
    TitleBar mTitleBar;
    @BindView(R.id.personal_data_img)
    ImageView mPersonalDataImg;
    @BindView(R.id.personal_data_yingfu_tv)
    TextView mPersonalDataYingfuTv;
    @BindView(R.id.personal_data_yingfu_rl)
    RelativeLayout mPersonalDataYingfuRl;
    @BindView(R.id.personal_data_xingbie_tv)
    TextView mPersonalDataXingbieTv;
    @BindView(R.id.personal_data_xingbie_rl)
    RelativeLayout mPersonalDataXingbieRl;

    @Override
    protected int getLayoutID() {
        return R.layout.activity_aboutus_personaldata;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initTitleBar();
        initCircle();
    }

    //圆形图片
    private void initCircle() {
        Glide.with(this)
            .load("http://pic35.nipic.com/20131121/2531170_145358633000_2.jpg")
            .apply(new RequestOptions().transform(new CircleCrop())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.mipmap.logo))
            .into(mPersonalDataImg);
    }

    private void initTitleBar() {
        mTitleBar.leftExit(this);
    }

    @OnClick({ R.id.personal_data_yingfu_rl, R.id.personal_data_xingbie_rl })
    public void onViewClicked(View view) {
        switch (view.getId()) {
            //用户名
            case R.id.personal_data_yingfu_rl:
                Intent intent = new Intent(this, UserNameActivety.class);
                startActivityForResult(intent,1);
                break;
            //性别
            case R.id.personal_data_xingbie_rl:
                initShowDialog();
                break;
        }
    }

    //姓名修改的回调
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1&&resultCode==2){
            String name = data.getStringExtra("name");
            mPersonalDataYingfuTv.setText(name);
        }
    }

    private void initShowDialog() {
        final BottomDialog dialog = new BottomDialog(this);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setBottomDialogListener(new BottomDialog.BottomDialogListener() {
            @Override
            public void succeed(String s) {
                if (s==null){
                    showOneToast("请选择性别");
                }else {
                    mPersonalDataXingbieTv.setText(s);
                    dialog.dismiss();
                }
                
            }

            @Override
            public void calloff() {
                showOneToast("取消");
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
