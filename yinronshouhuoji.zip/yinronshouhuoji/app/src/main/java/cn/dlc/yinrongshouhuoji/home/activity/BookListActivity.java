package cn.dlc.yinrongshouhuoji.home.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import butterknife.BindView;
import cn.dlc.commonlibrary.ui.widget.EmptyView;
import cn.dlc.commonlibrary.ui.widget.TitleBar;
import cn.dlc.commonlibrary.utils.rv_tool.EmptyRecyclerView;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;
import cn.dlc.yinrongshouhuoji.home.adpter.BookListAdapter;
import cn.dlc.yinrongshouhuoji.home.bean.BookListBean;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.lcodecore.tkrefreshlayout.header.progresslayout.ProgressLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public class BookListActivity extends BaseActivity {
    @BindView(R.id.titleBar)
    TitleBar mTitleBar;
    @BindView(R.id.empty_view)
    EmptyView mEmptyView;
    @BindView(R.id.rv_book_list)
    RecyclerView mRvBookList;
    @BindView(R.id.refreshLayout)
    TwinklingRefreshLayout mRefreshLayout;

    private int page;
    private BookListAdapter mBookListAdapter;
    private Map<Integer, List<BookListBean>> mFakeMap;

    @Override
    protected int getLayoutID() {
        return R.layout.activity_book_list;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initTitleBar();
        initFakeData();
        initRecyclerView();
    }

    private void initTitleBar() {
        mTitleBar.leftExit(this);
    }

    private void initFakeData() {
        mFakeMap = new HashMap<>();
        for (int i = 1; i < 4; i++) {
            List<BookListBean> mList = new ArrayList<>();
            mList.add(new BookListBean("红烧茄子", 2, 1521018923l));
            mList.add(new BookListBean("番茄炒蛋", 1, 1521018923l));
            mList.add(new BookListBean("辣子鸡", 3, 1521018923l));
            mList.add(new BookListBean("牛肉炒蛋", 2, 1521018923l));
            mFakeMap.put(i, mList);
        }
    }

    private void initRecyclerView() {
        mBookListAdapter = new BookListAdapter(getActivity());
        mRvBookList.setLayoutManager(
            new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mRvBookList.setAdapter(mBookListAdapter);
        EmptyRecyclerView.bind(mRvBookList, mEmptyView);
        initRefresh();
    }

    private void initRefresh() {
        ProgressLayout mProgressLayout = new ProgressLayout(getActivity());
        mProgressLayout.setColorSchemeResources(R.color.color_ff9557);
        mRefreshLayout.setHeaderView(mProgressLayout);
        mRefreshLayout.setFloatRefresh(true);
        mRefreshLayout.setEnableOverScroll(false);
        mRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(TwinklingRefreshLayout refreshLayout) {
                page = 1;
                getData();
            }

            @Override
            public void onLoadMore(TwinklingRefreshLayout refreshLayout) {
                getData();
            }
        });
        mRefreshLayout.startRefresh();
    }

    private void getData() {
        if (page == 1) {
            List<BookListBean> mList = mFakeMap.get(page);
            if (mList != null && mList.size() != 0) {
                page++;
                mBookListAdapter.setNewData(mList);
                mRefreshLayout.finishRefreshing();
            }
        } else {
            List<BookListBean> mList = mFakeMap.get(page);
            if (mList != null && mList.size() != 0) {
                page++;
                mBookListAdapter.appendData(mList);
            } else {
                showOneToast(R.string.meiyougengduoshuju);
            }
            mRefreshLayout.finishLoadmore();
        }
    }
}
