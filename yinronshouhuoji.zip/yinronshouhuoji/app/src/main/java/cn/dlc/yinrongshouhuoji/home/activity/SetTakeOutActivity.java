package cn.dlc.yinrongshouhuoji.home.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.OnClick;
import cn.dlc.commonlibrary.ui.widget.TitleBar;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public class SetTakeOutActivity extends BaseActivity {
    @BindView(R.id.titleBar)
    TitleBar mTitleBar;
    @BindView(R.id.tv_activated_grid)
    TextView mTvActivatedGrid;
    @BindView(R.id.img_reduce)
    ImageView mImgReduce;
    @BindView(R.id.tv_current_count)
    TextView mTvCurrentCount;
    @BindView(R.id.img_add)
    ImageView mImgAdd;
    @BindView(R.id.btn_confirm)
    Button mBtnConfirm;

    private int activatedCount;
    private int mCurrentCount;

    @Override
    protected int getLayoutID() {
        return R.layout.activity_set_take_out;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initTitleBar();
        initFakeData();
    }

    private void initTitleBar() {
        mTitleBar.leftExit(this);
    }

    private void initFakeData() {
        activatedCount = 20;
        mTvActivatedGrid.setText(String.valueOf(activatedCount));
        mTvCurrentCount.setText(String.valueOf(mCurrentCount));
    }

    @OnClick({ R.id.img_reduce, R.id.img_add, R.id.btn_confirm })
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.img_reduce:
                reduce();
                break;
            case R.id.img_add:
                add();
                break;
            case R.id.btn_confirm://立即放置
                confirm();
                break;
        }
    }

    private void add() {
        if (mCurrentCount < activatedCount) {
            mCurrentCount += 1;
            mTvCurrentCount.setText(String.valueOf(mCurrentCount));
        }
    }

    private void reduce() {
        if (mCurrentCount > 0) {
            mCurrentCount -= 1;
            mTvCurrentCount.setText(String.valueOf(mCurrentCount));
        }
    }

    private void confirm() {
        int max = Integer.valueOf(mTvCurrentCount.getText().toString());
        if (max == 0) {
            showOneToast(R.string.zongshuliangbunengweiling);
            return;
        }
        startActivity(ChooseGoodsActivity.newIntent(this, max));
    }
}
