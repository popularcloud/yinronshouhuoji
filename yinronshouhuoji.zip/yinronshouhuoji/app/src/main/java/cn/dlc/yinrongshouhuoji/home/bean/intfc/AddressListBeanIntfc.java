package cn.dlc.yinrongshouhuoji.home.bean.intfc;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public interface AddressListBeanIntfc {
    String getAddressArea();//地址地区
    String getAddressDetail();//详细地址
}
