package cn.dlc.yinrongshouhuoji.home.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.OnClick;
import cn.dlc.commonlibrary.ui.widget.EmptyView;
import cn.dlc.commonlibrary.utils.rv_tool.EmptyRecyclerView;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;
import cn.dlc.yinrongshouhuoji.home.adpter.AddressListAdapter;
import cn.dlc.yinrongshouhuoji.home.bean.AddressListBean;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.lcodecore.tkrefreshlayout.header.progresslayout.ProgressLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public class SetAddressActivity extends BaseActivity {
    @BindView(R.id.img_exit)
    ImageView mImgExit;
    @BindView(R.id.edit_key_word)
    EditText mEditKeyWord;
    @BindView(R.id.img_search)
    ImageView mImgSearch;
    @BindView(R.id.tv_current_address)
    TextView mTvCurrentAddress;
    @BindView(R.id.empty_view)
    EmptyView mEmptyView;
    @BindView(R.id.rv_address)
    RecyclerView mRvAddress;
    @BindView(R.id.refreshLayout)
    TwinklingRefreshLayout mRefreshLayout;

    private int page;
    private AddressListAdapter mAddressListAdapter;
    private Map<Integer, List<AddressListBean>> mFakeMap;

    @Override
    protected int getLayoutID() {
        return R.layout.activity_set_address;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initFakeData();
        initRecyclerView();
    }

    private void initFakeData() {
        mFakeMap = new HashMap<>();
        for (int i = 1; i < 4; i++) {
            List<AddressListBean> mList = new ArrayList<>();
            mList.add(new AddressListBean("东莞市高盛科技北区对面",
                "广东省东莞市南城区高盛科技园高盛科技港迪尔西303广东省东莞市南城区高盛科技园高盛科技港迪尔西303"));
            mList.add(new AddressListBean("东莞市高盛科技北区对面",
                "广东省东莞市南城区高盛科技园高盛科技港迪尔西303广东省东莞市南城区高盛科技园高盛科技港迪尔西303"));
            mList.add(new AddressListBean("东莞市高盛科技北区对面",
                "广东省东莞市南城区高盛科技园高盛科技港迪尔西303广东省东莞市南城区高盛科技园高盛科技港迪尔西303"));
            mList.add(new AddressListBean("东莞市高盛科技北区对面",
                "广东省东莞市南城区高盛科技园高盛科技港迪尔西303广东省东莞市南城区高盛科技园高盛科技港迪尔西303"));
            mFakeMap.put(i, mList);
        }

        mTvCurrentAddress.setText("广东省东莞市南城区高盛科技园高盛科技港迪尔西303广东省东莞市南城区高盛科技园高盛科技港迪尔西303");
    }

    private void initRecyclerView() {
        mAddressListAdapter = new AddressListAdapter();
        mRvAddress.setLayoutManager(
            new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mRvAddress.setAdapter(mAddressListAdapter);
        EmptyRecyclerView.bind(mRvAddress, mEmptyView);
        initRefresh();
    }

    private void initRefresh() {
        ProgressLayout mProgressLayout = new ProgressLayout(getActivity());
        mProgressLayout.setColorSchemeResources(R.color.color_ff9557);
        mRefreshLayout.setHeaderView(mProgressLayout);
        mRefreshLayout.setFloatRefresh(true);
        mRefreshLayout.setEnableOverScroll(false);
        mRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(TwinklingRefreshLayout refreshLayout) {
                page = 1;
                getData();
            }

            @Override
            public void onLoadMore(TwinklingRefreshLayout refreshLayout) {
                getData();
            }
        });
        mRefreshLayout.startRefresh();
    }

    private void getData() {
        if (page == 1) {
            List<AddressListBean> mList = mFakeMap.get(page);
            if (mList != null && mList.size() != 0) {
                page++;
                mAddressListAdapter.setNewData(mList);
                mRefreshLayout.finishRefreshing();
            }
        } else {
            List<AddressListBean> mList = mFakeMap.get(page);
            if (mList != null && mList.size() != 0) {
                page++;
                mAddressListAdapter.appendData(mList);
            } else {
                showOneToast(R.string.meiyougengduoshuju);
            }
            mRefreshLayout.finishLoadmore();
        }
    }

    @OnClick({ R.id.img_exit, R.id.img_search })
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.img_exit:
                finish();
                break;
            case R.id.img_search:
                search();
                break;
        }
    }

    private void search() {
        //具体地图搜索不知道是不是用第三方搜索还是本地搜索，本地搜索参考ChooseGoodsActivity的initSearch
    }
}
