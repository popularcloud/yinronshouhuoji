package cn.dlc.yinrongshouhuoji;

import android.os.Bundle;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;
import cn.dlc.yinrongshouhuoji.home.activity.MainActivity;

public class WelcomeActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //填入你要启动的activity
        startActivity(MainActivity.class);

        finish();
    }

    @Override
    protected int getLayoutID() {
        return 0;
    }
}
