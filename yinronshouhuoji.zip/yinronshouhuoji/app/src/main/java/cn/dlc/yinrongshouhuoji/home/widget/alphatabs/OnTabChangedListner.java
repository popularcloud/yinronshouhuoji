package cn.dlc.yinrongshouhuoji.home.widget.alphatabs;


public interface OnTabChangedListner {
    void onTabSelected(int tabNum);
}
