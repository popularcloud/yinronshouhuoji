package cn.dlc.yinrongshouhuoji.home.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.OnClick;
import cn.dlc.commonlibrary.ui.widget.TitleBar;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;
import cn.dlc.yinrongshouhuoji.home.adpter.GridListAdapter;
import cn.dlc.yinrongshouhuoji.home.bean.DeviceListBean;
import cn.dlc.yinrongshouhuoji.home.bean.GridListBean;
import cn.dlc.yinrongshouhuoji.home.utlis.helper.DeviceAddressHelper;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public class DeviceDetailActivity extends BaseActivity {
    @BindView(R.id.titleBar)
    TitleBar mTitleBar;
    @BindView(R.id.tv_device_no)
    TextView mTvDeviceNo;
    @BindView(R.id.tv_device_name)
    TextView mTvDeviceName;
    @BindView(R.id.tv_device_address)
    TextView mTvDeviceAddress;
    @BindView(R.id.tv_grid_sum)
    TextView mTvGridSum;
    @BindView(R.id.tv_kongcang)
    TextView mTvKongcang;
    @BindView(R.id.tv_konghe)
    TextView mTvKonghe;
    @BindView(R.id.tv_guzhang)
    TextView mTvGuzhang;
    @BindView(R.id.tv_weiguanmen)
    TextView mTvWeiguanmen;
    @BindView(R.id.tv_waimai)
    TextView mTvWaimai;
    @BindView(R.id.tv_yuding)
    TextView mTvYuding;
    @BindView(R.id.tv_guoqi)
    TextView mTvGuoqi;
    @BindView(R.id.tv_waimai_detail)
    TextView mTvWaimaiDetail;
    @BindView(R.id.tv_yuding_detail)
    TextView mTvYudingDetail;
    @BindView(R.id.rv_grid)
    RecyclerView mRvGrid;

    private static final String EXTRA_BEAN = "extra_bean";

    private DeviceListBean mDeviceListBean;
    private GridListAdapter mGridListAdapter;
    private List<GridListBean> mFakeList;

    public static Intent newIntent(Context mContext, DeviceListBean mDeviceListBean) {
        Intent mIntent = new Intent(mContext, DeviceDetailActivity.class);
        mIntent.putExtra(EXTRA_BEAN, mDeviceListBean);
        return mIntent;
    }

    @Override
    protected int getLayoutID() {
        return R.layout.activity_device_detail;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        resolveIntent();
        initTitleBar();
        initFakeData();
        initRecyclerView();
    }

    private void resolveIntent() {
        mDeviceListBean = (DeviceListBean) getIntent().getSerializableExtra(EXTRA_BEAN);
    }

    private void initTitleBar() {
        mTitleBar.leftExit(this);
        mTitleBar.setTitle(mDeviceListBean.getDeviceName());
    }

    private void initFakeData() {
        mTvDeviceNo.setText(mDeviceListBean.getDeviceNo());
        mTvDeviceName.setText(mDeviceListBean.getDeviceName());
        String mDeviceAddress = mDeviceListBean.getDeviceAddress();
        DeviceAddressHelper.setDeviceAddress(this, mTvDeviceAddress, mDeviceAddress);
        mTvGridSum.setText(Html.fromHtml(getString(R.string.zongshu_, 50)));
        //格子里面的ID根据中文拼音命名，英文水平有限
        mTvKongcang.setText(getString(R.string.kongcang, 35));
        mTvWaimai.setText(getString(R.string.waimai, 5));
        mTvKonghe.setText(getString(R.string.konghe, 8));
        mTvYuding.setText(getString(R.string.yuding, 10));
        mTvGuzhang.setText(getString(R.string.guzhang, 8));
        mTvGuoqi.setText(getString(R.string.guoqi, 10));
        mTvWeiguanmen.setText(getString(R.string.weiguanmen, 10));

        mFakeList = new ArrayList<>();
        mFakeList.add(new GridListBean("101", 0));
        mFakeList.add(new GridListBean("102", 1));
        mFakeList.add(new GridListBean("103", 2));
        mFakeList.add(new GridListBean("104", 4));
        mFakeList.add(new GridListBean("105", 4));
        mFakeList.add(new GridListBean("106", 4));
        mFakeList.add(new GridListBean("107", 5));
        mFakeList.add(new GridListBean("108", 5));
        mFakeList.add(new GridListBean("109", 0));
        mFakeList.add(new GridListBean("110", 6));
        mFakeList.add(new GridListBean("111", 6));
        mFakeList.add(new GridListBean("112", 6));
        mFakeList.add(new GridListBean("113", 2));
        mFakeList.add(new GridListBean("114", 2));
        mFakeList.add(new GridListBean("115", 1));
        mFakeList.add(new GridListBean("116", 1));
        mFakeList.add(new GridListBean("117", 4));
        mFakeList.add(new GridListBean("118", 5));
        mFakeList.add(new GridListBean("119", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
        mFakeList.add(new GridListBean("120", 0));
    }

    private void initRecyclerView() {
        mGridListAdapter = new GridListAdapter();
        mRvGrid.setLayoutManager(new GridLayoutManager(getActivity(), 7));
        mRvGrid.setNestedScrollingEnabled(false);
        mRvGrid.setAdapter(mGridListAdapter);
        mGridListAdapter.setNewData(mFakeList);
    }

    @OnClick({ R.id.tv_waimai_detail, R.id.tv_yuding_detail, R.id.tv_device_address })
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_waimai_detail://外卖详情
                startActivity(TakeOutListActivity.class);
                break;
            case R.id.tv_yuding_detail://预定详情
                startActivity(BookListActivity.class);
                break;
            case R.id.tv_device_address:
                startActivity(SetAddressActivity.class);
                break;
        }
    }
}
