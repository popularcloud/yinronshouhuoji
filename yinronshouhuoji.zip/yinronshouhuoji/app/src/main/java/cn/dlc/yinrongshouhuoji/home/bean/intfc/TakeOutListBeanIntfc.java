package cn.dlc.yinrongshouhuoji.home.bean.intfc;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public interface TakeOutListBeanIntfc {
    String getGridNo();//格子编号

    String getGoodsName();//商品名称

    int getGoodsCount();//商品数量

    long getDate();//上架时间
}
