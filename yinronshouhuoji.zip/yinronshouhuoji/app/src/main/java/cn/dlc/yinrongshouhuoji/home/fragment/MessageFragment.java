package cn.dlc.yinrongshouhuoji.home.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import butterknife.BindView;
import cn.dlc.commonlibrary.ui.widget.EmptyView;
import cn.dlc.commonlibrary.utils.rv_tool.EmptyRecyclerView;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.fragment.BaseFragment;
import cn.dlc.yinrongshouhuoji.home.adpter.MessageListAdapter;
import cn.dlc.yinrongshouhuoji.home.bean.MessageListBean;
import cn.dlc.yinrongshouhuoji.home.widget.dialog.TwoButtonDialog;
import cn.dlc.yinrongshouhuoji.personal.view.MyDialog;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;
import com.lcodecore.tkrefreshlayout.header.progresslayout.ProgressLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by liuwenzhuo on 2018/3/13.
 */

public class MessageFragment extends BaseFragment {
    @BindView(R.id.empty_view)
    EmptyView mEmptyView;
    @BindView(R.id.rv_message_list)
    RecyclerView mRvMessageList;
    @BindView(R.id.refreshLayout)
    TwinklingRefreshLayout mRefreshLayout;

    private int page;
    private MessageListAdapter mMessageListAdapter;
    private Map<Integer, List<MessageListBean>> mFakeMap;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_message;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initFakeData();
        initRecyclerView();
    }

    private void initFakeData() {
        mFakeMap = new HashMap<>();
        for (int i = 1; i < 4; i++) {
            List<MessageListBean> mList = new ArrayList<>();
            mList.add(new MessageListBean("客户预约订餐订单", "15899661573客户在0354售货机取餐了", 1520993857l, 0,
                "15899661573", "火锅鱼饭", 1520993857l));
            mList.add(new MessageListBean("客户预约订餐订单", "15899661573客户在0354售货机取餐了", 1520993857l, 1,
                "15899661573", "火锅鱼饭", 1520993857l));
            mList.add(new MessageListBean("客户预约订餐订单", "15899661573客户在0354售货机取餐了", 1520993857l, 2,
                "15899661573", "火锅鱼饭", 1520993857l));
            mList.add(new MessageListBean("客户预约订餐订单", "15899661573客户在0354售货机取餐了", 1520993857l, 0,
                "15899661573", "火锅鱼饭", 1520993857l));
            mFakeMap.put(i, mList);
        }
    }

    private void initRecyclerView() {
        mMessageListAdapter = new MessageListAdapter(getActivity());
        mMessageListAdapter.setOnClickButtonListener(
            new MessageListAdapter.OnClickButtonListener() {
                @Override
                public void onClickCancel(MessageListBean mMessageListBean) {
                    showCancelOrdersDialog(mMessageListBean);
                }

                @Override
                public void onClickAccept(MessageListBean mMessageListBean) {
                    showAcceptOrdersDialog(mMessageListBean);
                }
            });
        mRvMessageList.setLayoutManager(
            new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mRvMessageList.setAdapter(mMessageListAdapter);
        EmptyRecyclerView.bind(mRvMessageList, mEmptyView);
        initRefresh();
    }

    private void showCancelOrdersDialog(MessageListBean mMessageListBean) {
        //mMessageListBean 可能需要ID什么的，看接口
        TwoButtonDialog mCancelOrdersDialog = new TwoButtonDialog(getActivity());
        mCancelOrdersDialog.setTitle(R.string.tishi);
        mCancelOrdersDialog.setContent(R.string.shifouquerenjujuedingdan);
        mCancelOrdersDialog.setBtnConfirm(R.string.queding);
        mCancelOrdersDialog.setBtnCancel(R.string.quxiao);
        mCancelOrdersDialog.setOnClickButtonListener(new TwoButtonDialog.OnClickButtonListener() {
            @Override
            public void onClickConfirm() {
                showCancelTipsDialog(false);
            }

            @Override
            public void onClickCancel() {

            }
        });
        mCancelOrdersDialog.show();
    }

    private void showAcceptOrdersDialog(MessageListBean mMessageListBean) {
        //mMessageListBean 可能需要ID什么的，看接口
        TwoButtonDialog mCancelOrdersDialog = new TwoButtonDialog(getActivity());
        mCancelOrdersDialog.setTitle(R.string.tishi);
        mCancelOrdersDialog.setContent(R.string.shifouquerenjieshoudingdan);
        mCancelOrdersDialog.setBtnConfirm(R.string.queding);
        mCancelOrdersDialog.setBtnCancel(R.string.quxiao);
        mCancelOrdersDialog.setOnClickButtonListener(new TwoButtonDialog.OnClickButtonListener() {
            @Override
            public void onClickConfirm() {
                showAcceptTipsDialog(true);
            }

            @Override
            public void onClickCancel() {

            }
        });
        mCancelOrdersDialog.show();
    }

    private void showCancelTipsDialog(boolean b) {
        MyDialog mMyDialog = new MyDialog(getActivity());
        if (b) {
            mMyDialog.setIsText(R.string.chenggongjujuedingdan);
        } else {
            mMyDialog.setIsText(R.string.jujueshibai);
        }
        mMyDialog.setIsTrue(b);
        mMyDialog.show();
    }

    private void showAcceptTipsDialog(boolean b) {
        MyDialog mMyDialog = new MyDialog(getActivity());
        if (b) {
            mMyDialog.setIsText(R.string.chenggongjieshoudingdan);
        } else {
            mMyDialog.setIsText(R.string.jieshoushibai);
        }
        mMyDialog.setIsTrue(b);
        mMyDialog.show();
    }

    private void initRefresh() {
        ProgressLayout mProgressLayout = new ProgressLayout(getActivity());
        mProgressLayout.setColorSchemeResources(R.color.color_ff9557);
        mRefreshLayout.setHeaderView(mProgressLayout);
        mRefreshLayout.setFloatRefresh(true);
        mRefreshLayout.setEnableOverScroll(false);
        mRefreshLayout.setOnRefreshListener(new RefreshListenerAdapter() {
            @Override
            public void onRefresh(TwinklingRefreshLayout refreshLayout) {
                page = 1;
                getData();
            }

            @Override
            public void onLoadMore(TwinklingRefreshLayout refreshLayout) {
                getData();
            }
        });
        mRefreshLayout.startRefresh();
    }

    private void getData() {
        if (page == 1) {
            List<MessageListBean> mList = mFakeMap.get(page);
            if (mList != null && mList.size() != 0) {
                page++;
                mMessageListAdapter.setNewData(mList);
                mRefreshLayout.finishRefreshing();
            }
        } else {
            List<MessageListBean> mList = mFakeMap.get(page);
            if (mList != null && mList.size() != 0) {
                page++;
                mMessageListAdapter.appendData(mList);
            } else {
                showOneToast(R.string.meiyougengduoshuju);
            }
            mRefreshLayout.finishLoadmore();
        }
    }
}
