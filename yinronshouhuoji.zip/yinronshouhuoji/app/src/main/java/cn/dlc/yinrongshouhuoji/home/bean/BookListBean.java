package cn.dlc.yinrongshouhuoji.home.bean;

import cn.dlc.yinrongshouhuoji.home.bean.intfc.BookListBeanIntfc;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public class BookListBean implements BookListBeanIntfc {

    String goodsName;//商品名称

    int goodsCount;//商品数量

    long date;//预定时间

    @Override
    public String getGoodsName() {
        return goodsName;
    }

    @Override
    public int getGoodsCount() {
        return goodsCount;
    }

    @Override
    public long getDate() {
        return date;
    }

    public BookListBean(String goodsName, int goodsCount, long date) {
        this.goodsName = goodsName;
        this.goodsCount = goodsCount;
        this.date = date;
    }

    @Override
    public String toString() {
        return "BookListBean{"
            + "goodsName='"
            + goodsName
            + '\''
            + ", goodsCount="
            + goodsCount
            + ", date="
            + date
            + '}';
    }
}
