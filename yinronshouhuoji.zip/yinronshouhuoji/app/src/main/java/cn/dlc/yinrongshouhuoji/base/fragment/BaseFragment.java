package cn.dlc.yinrongshouhuoji.base.fragment;

import cn.dlc.commonlibrary.ui.base.BaseCommonFragment;

/**
 * Created by liuwenzhuo on 2018/3/13.
 */

public abstract class BaseFragment extends BaseCommonFragment {

}
