package cn.dlc.yinrongshouhuoji.login.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.OnClick;
import cn.dlc.commonlibrary.utils.CountDownHelper;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;
import cn.dlc.yinrongshouhuoji.home.activity.MainActivity;
import java.util.concurrent.TimeUnit;

/**
 * Created by liuwenzhuo on 2018/3/13.
 */

public class LoginActivity extends BaseActivity {

    @BindView(R.id.edit_phone)
    EditText mEditPhone;
    @BindView(R.id.edit_check_code)
    EditText mEditCheckCode;
    @BindView(R.id.tv_get_check_code)
    TextView mTvGetCheckCode;
    @BindView(R.id.btn_login)
    Button mBtnLogin;

    @Override
    protected int getLayoutID() {
        return R.layout.activity_login;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @OnClick({ R.id.tv_get_check_code, R.id.btn_login })
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.tv_get_check_code:
                getCheckCode();
                break;
            case R.id.btn_login:
                login();
                break;
        }
    }

    private void getCheckCode() {
        String mPhone = mEditPhone.getText().toString();
        if (TextUtils.isEmpty(mPhone) || mPhone.length() != 11) {
            showOneToast(R.string.qingshuruzhengquedeshoujihao);
            return;
        }
        CountDownHelper countDownHelper = new CountDownHelper(60, 1, TimeUnit.SECONDS) {
            @Override
            public void onTick(long millisUntilFinished) {
                try {
                    mTvGetCheckCode.setText(millisUntilFinished / 1000 + "");
                } catch (Exception e) {
                    new Throwable("报空我就try-catch").printStackTrace();
                }
            }

            @Override
            public void onFinish() {
                try {
                    mTvGetCheckCode.setText("重新获取");
                } catch (Exception e) {
                    new Throwable("报空我就try-catch").printStackTrace();
                }
            }
        };
        countDownHelper.start();
    }

    private void login() {
        String mPhone = mEditPhone.getText().toString();
        String mCheckCode = mEditCheckCode.getText().toString();
        if (TextUtils.isEmpty(mPhone) || mPhone.length() != 11) {
            showOneToast(R.string.qingshuruzhengquedeshoujihao);
            return;
        }
        if (TextUtils.isEmpty(mCheckCode) || mCheckCode.length() != 6) {
            showOneToast(R.string.qingshuruzhengquedeyanzhengma);
            return;
        }
        startActivity(MainActivity.class);
    }
}
