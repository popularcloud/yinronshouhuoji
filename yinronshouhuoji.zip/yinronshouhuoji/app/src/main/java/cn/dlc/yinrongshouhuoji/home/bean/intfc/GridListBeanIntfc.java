package cn.dlc.yinrongshouhuoji.home.bean.intfc;

/**
 * Created by liuwenzhuo on 2018/3/14.
 */

public interface GridListBeanIntfc {
    String getGridNo();//格子编号

    int getStatus();//格子状态
}
