package cn.dlc.yinrongshouhuoji.personal.activity;

import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.TextView;
import butterknife.BindView;
import cn.dlc.commonlibrary.ui.widget.TitleBar;
import cn.dlc.yinrongshouhuoji.R;
import cn.dlc.yinrongshouhuoji.base.activity.BaseActivity;

/**
 * 页面:李旭康  on  2018/3/13.
 * 对接口:
 * 作用:
 */

public class AboutUsActivity extends BaseActivity {
    @BindView(R.id.titleBar)
    TitleBar mTitleBar;
    @BindView(R.id.setting_update_numb_tv)
    TextView mSettingUpdateNumbTv;
    @BindView(R.id.setting_update_rl)
    RelativeLayout mSettingUpdateRl;
    @BindView(R.id.aboutus_yinwen)
    TextView mAboutusYinwen;

    @Override
    protected int getLayoutID() {
        return R.layout.activity_aboutus;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        initTitleBar();
    }

    private void initTitleBar() {
        mTitleBar.leftExit(this);
    }
}
