package cn.dlc.yinrongshouhuoji.pad.base.activity;

import cn.dlc.commonlibrary.ui.base.BaseCommonActivity;

/**
 * Created by liuwenzhuo on 2018/3/13.
 */

public abstract class BaseActivity extends BaseCommonActivity {

    @Override
    protected void beforeSetContentView() {
        super.beforeSetContentView();
        setTranslucentStatus(); // 沉浸状态栏
    }
}
