package cn.dlc.yinrongshouhuoji.pad;

import android.os.Bundle;
import cn.dlc.yinrongshouhuoji.pad.base.activity.BaseActivity;

/**
 * Created by liuwenzhuo on 2018/3/13.
 */

public class WelcomeActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //填入你要启动的activity
        //startActivity();
        //finish();
    }

    @Override
    protected int getLayoutID() {
        return 0;
    }
}
